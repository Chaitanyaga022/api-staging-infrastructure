import json
import requests
import boto3
from datetime import datetime

def lambda_handler(event, context):
    url = "https://api.open-meteo.com/v1/forecast?latitude=-37.8136&longitude=144.9631&current_weather=true"
    
    response = requests.get(url)
    
    if response.status_code == 200:
        weather_data = response.json()
        
        current_weather = weather_data.get("current_weather")
        
        bucket_name = 'api-staging-cg'
        file_name = f"weather_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        # Initialize S3 client
        s3 = boto3.client('s3')
        
        s3.put_object(
            Bucket=bucket_name,
            Key=file_name,
            Body=json.dumps(current_weather),
            ContentType='application/json'
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps('Weather data successfully stored in S3.')
        }
    else:
        return {
            'statusCode': 500,
            'body': json.dumps('Failed to fetch weather data from Open-Meteo.')
        }
